To run program

app-front
use live server visual studio plugin 
http://localhost:2800/wap-onlinedictionary-app/app-front/

app-server-node
node appserver.js

test use postman 
http://localhost:3000/service/wap/dictionary?word=Ar
http://localhost:3000/service/wap/dictionary?word=Flower